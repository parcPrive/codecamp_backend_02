import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { Strategy } from 'passport-google-oauth20';

@Injectable()
export class JwtGoogleStrategy extends PassportStrategy(Strategy, 'google') {
  constructor() {
    super({
      clientID:
        '361351457379-nlm1ps1lqa9dnf24ekai4p6vbcqs4b4n.apps.googleusercontent.com',
      clientSecret: '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',
      callbackURL: 'http://localhost:3000/login/google',
      scope: ['email', 'profile'],
    });
  }

  validate(accessToken: string, refreshToken: string, profile: any) {
    console.log(accessToken);
    console.log(refreshToken);
    console.log(profile);
    return {
      email: profile.emails[0].value,
      pw: '1111',
      phone: '123123',
      person: '123123',
      address: '13123',
    };
  }
}
