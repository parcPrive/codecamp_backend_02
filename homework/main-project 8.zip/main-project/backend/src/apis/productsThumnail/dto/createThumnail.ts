import { Field, InputType } from '@nestjs/graphql';

@InputType()
export class CreateThumnailInput {
  @Field(() => [String])
  imageeurl: string[];
}
