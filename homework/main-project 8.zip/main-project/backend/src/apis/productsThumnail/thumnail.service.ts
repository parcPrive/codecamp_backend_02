import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ProductThumnail } from './entities/productThumnail.entity';

@Injectable()
export class ThumnailService {
  constructor(
    @InjectRepository(ProductThumnail)
    private readonly productThumnailRepository: Repository<ProductThumnail>,
  ) {}
  async create({ imageurl, productId }) {
    console.log('⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒');
    const productThumnail = await this.productThumnailRepository.save({
      imageurl: imageurl,
      productId: productId,
    });
    console.log('⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒');
    console.log(productThumnail);
    console.log('⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒⚒');
    return productThumnail;
  }
}
