import { Args, Mutation, Resolver } from '@nestjs/graphql';
import { CreateThumnailInput } from './dto/createThumnail';
import { ProductThumnail } from './entities/productThumnail.entity';
import { ThumnailService } from './thumnail.service';

@Resolver()
export class ThumnailResolver {
  constructor(private readonly thumnailService: ThumnailService) {}

  @Mutation(() => ProductThumnail)
  async createThumnail(
    //
    @Args({ name: 'imageurl', type: () => [String] })
    imageurl: CreateThumnailInput[],
    @Args('productid') productId: string,
  ) {
    return await this.thumnailService.create({ imageurl, productId });
  }
}
