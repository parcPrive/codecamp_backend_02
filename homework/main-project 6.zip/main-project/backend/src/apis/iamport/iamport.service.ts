import {
  ConflictException,
  HttpException,
  Injectable,
  UnprocessableEntityException,
} from '@nestjs/common';
import axios from 'axios';
@Injectable()
export class IamportService {
  async getToken() {
    //검증로직들!!!
    // 1. 아임포트에 요청해서 결제 완료 기록이 존재하는 확인한다.
    try {
      const result = await axios.post('https://api.iamport.kr/users/getToken', {
        imp_key: '0624432526912208',
        imp_secret:
          '4d1d9f754a0136d2f683f25ad7bef6897ef04890a17d2c0a2678183f1a8b7e50d665373e33c64ff7',
      });
      console.log(result.data.response.access_token);
      return result.data.response.access_token;
    } catch (error) {
      throw new HttpException(
        error.response.data.message,
        error.response.status,
      );
    }
  }
  async checkPaid({ impUid, amount, token }) {
    try {
      const result = await axios.get(
        `https://api.iamport.kr/payments/${impUid}`,
        {
          headers: { Authorization: token },
        },
      );
      if (result.data.response.status !== 'paid')
        throw new ConflictException('결제 내역이 존재하지 않습니다.');

      if (result.data.response.amount !== amount)
        throw new UnprocessableEntityException('결제 금액이 잘못 되었습니다.');
      console.log(result.data.response.amount);
      console.log(result);
    } catch (error) {
      if (error?.response?.data?.message) {
        throw new HttpException(
          error.response.data.message,
          error.response.status,
        );
      } else {
        throw error;
      }
    }
  }
  async cancel({ impUid, token }) {
    try {
      const result = await axios.post(
        `https://api.iamport.kr/payments/cancel`,
        { imp_uid: impUid },
        { headers: { Authorization: token } },
      );
      return result.data.response.cancel_amount;
    } catch (error) {
      throw new HttpException(
        error.response.data.message,
        error.response.status,
      );
    }
  }
}
