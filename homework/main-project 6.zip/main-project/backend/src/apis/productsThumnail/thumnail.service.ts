import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ProductThumnail } from './entities/productThumnail.entity';

@Injectable()
export class ThumnailService {
  constructor(
    @InjectRepository(ProductThumnail)
    private readonly productThumnailRepository: Repository<ProductThumnail>,
  ) {}
  async create({ createThumnailInput }) {
    const productThumnail = this.productThumnailRepository.save({
      ...createThumnailInput,
    });
    return productThumnail;
  }
}
