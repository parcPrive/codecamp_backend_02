import { Product } from 'src/apis/products/entities/product.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity()
export class ProductThumnail {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column()
  imageurl: string;

  @Column({ default: 1 })
  imagecheck: string;

  @CreateDateColumn()
  dateAt: Date;

  @ManyToOne(() => Product)
  product: Product;
}
