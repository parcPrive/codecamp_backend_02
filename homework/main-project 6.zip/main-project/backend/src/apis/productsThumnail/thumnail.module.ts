import { Module } from '@nestjs/common';
import { ThumnailResolver } from './thumnail.resolver';
import { ThumnailService } from './thumnail.service';

@Module({
  providers: [ThumnailResolver, ThumnailService],
})
export class ThumnailModule {}
