import { ConflictException, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import axios from 'axios';
import { Repository } from 'typeorm';
import {
  PointTransaction,
  POINT_TRANSACTION_STATUS_ENUM,
} from '../pointTransaction/antities/pointTranscation.entity';
import { User } from '../user/entities/user.entity';

@Injectable()
export class IamportService {
  constructor(
    @InjectRepository(PointTransaction)
    private readonly pointTransactionRepository: Repository<PointTransaction>,
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}
  async create({ impUid, amount, merchantUid, currentUser }) {
    const getToken = await axios({
      url: 'https://api.iamport.kr/users/getToken',
      method: 'post', // POST method
      headers: { 'Content-Type': 'application/json' }, // "Content-Type": "application/json"
      data: {
        imp_key: '0624432526912208', // REST API키
        imp_secret:
          '4d1d9f754a0136d2f683f25ad7bef6897ef04890a17d2c0a2678183f1a8b7e50d665373e33c64ff7', // REST API Secret
      },
    });
    const { access_token } = getToken.data.response;
    // imp_uid로 아임포트 서버에서 결제 정보 조회
    const getPaymentData = await axios({
      url: `https://api.iamport.kr/payments/${impUid}`, // imp_uid 전달
      method: 'get', // GET method
      headers: { Authorization: access_token }, // 인증 토큰 Authorization header에 추가
    });
    const paymentData = getPaymentData.data.response; // 조회한 결제 정보
    await this.pointTransactionRepository.save({
      impUid: impUid,
      amount: amount,
      merchantUid: merchantUid,
      user: currentUser.id,
      status: POINT_TRANSACTION_STATUS_ENUM.PAYMENT,
    });

    // DB에서 결제되어야 하는 금액 조회
    const order = await this.pointTransactionRepository.findOne({
      merchantUid: paymentData.merchant_uid,
    });
    //if (!order) throw new ConflictException('다시 확인해주세요');
    const amountToBePaid = order.amount;
    if (amount === amountToBePaid) {
      // 2. 유저의 돈 찾아오기
      const user = await this.userRepository.findOne({ id: currentUser.id });
      // 3. 유저의 돈 업데이트
      await this.userRepository.update(
        { id: user.id }, //조건
        { point: user.point + amount }, //변경내용
      );
    }
    return paymentData;
  }
  async refund({ impUid, amount, currentUser }) {
    const getToken = await axios({
      url: 'https://api.iamport.kr/users/getToken',
      method: 'post', // POST method
      headers: { 'Content-Type': 'application/json' }, // "Content-Type": "application/json"
      data: {
        imp_key: '0624432526912208', // REST API키
        imp_secret:
          '4d1d9f754a0136d2f683f25ad7bef6897ef04890a17d2c0a2678183f1a8b7e50d665373e33c64ff7', // REST API Secret
      },
    });
    const { access_token } = getToken.data.response;
    //유저 정보가져오기
    // imp_uid로 아임포트 서버에서 결제 정보 조회
    const getPaymentData = await axios({
      url: `https://api.iamport.kr/payments/${impUid}`, // imp_uid 전달
      method: 'get', // GET method
      headers: { Authorization: access_token }, // 인증 토큰 Authorization header에 추가
    });
    const paymentData = getPaymentData.data.response; // 조회한 결제 정보
  }
}
