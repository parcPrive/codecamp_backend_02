import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { IamportService } from '../iamport/iamport.service';
import { PointTransaction } from './antities/pointTranscation.entity';

@Injectable()
export class PointTransactionService {
  constructor(
    @InjectRepository(PointTransaction)
    private readonly pointTransactionRepository: Repository<PointTransaction>,
    private readonly iamService: IamportService,
  ) {}

  async create({ impUid, amount, merchantUid, currentUser }) {
    const token = await this.iamService.create({
      impUid,
      amount,
      merchantUid,
      currentUser,
    });
    console.log(
      '🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨',
    );
    console.log(token);
    console.log(
      '🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨🔨',
    );

    // 4. 최종결과 프론트엔드에 돌려주기
  }

  async refund({ impUid, amount, currentUser }) {
    const refundimformation = await this.iamService.refund({
      impUid,
      amount,
      currentUser,
    });
  }
}
