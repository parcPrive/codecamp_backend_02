
import {checkValidationPhone, getToken, sendTokenToSMS } from "./phone.js";


import express from "express"
import swaggerUi from 'swagger-ui-express'
import swaggerJsdoc from 'swagger-jsdoc'
import { options } from './swagger/config.js'
import mongoose from 'mongoose'

import {Token} from "./models/token.model.js"

import dotenv from 'dotenv'
dotenv.config()

const app = express()
app.use(express.json())
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerJsdoc(options)));


const port = 3001

app.post('/tokens/phone', async (req, res) => {
  const myphone = req.body.myphone
  //1.휴대폰번호 자릿수 맞는지 확인하기
  const isValid = checkValidationPhone(myphone)
  if(isValid){
    //2.핸드폰 토큰 6자리 만들기
    const mytoken = getToken()
    //3번 핸드폰번호에 토큰 전송하기
    sendTokenToSMS(myphone, mytoken)
    
    res.send("인증완료!!")
    const token =  new Token({
      token: mytoken,
      phone: myphone,
      isAuth: false
   
     })
    // if(myphone === token.phone){
      
    // }
    console.log(token.findone({phone:"010"}))
   await token.save()
  }

})
app.patch('/tokens/phone', async (req, res) => {
  const myphone = req.body.myphone
  const result = await Token.find()
  if(myphone !== result.phone){
    res.send("false")
  }else{
    res.send("true")
  }
  res.send(result)
})



//몽고DB 접속!!
mongoose.connect("mongodb://my-database:27017/phone")

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

let a = "11"
