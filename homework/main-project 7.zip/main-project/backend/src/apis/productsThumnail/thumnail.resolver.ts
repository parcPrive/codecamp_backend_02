import { Args, Mutation, Resolver } from '@nestjs/graphql';
import { CreateThumnailInput } from './dto/createThumnail';
import { ProductThumnail } from './entities/productThumnail.entity';
import { ThumnailService } from './thumnail.service';

@Resolver()
export class ThumnailResolver {
  constructor(private readonly thumnailService: ThumnailService) {}

  @Mutation(() => ProductThumnail)
  createThumnail(
    @Args('imaegurl') imageurl: string, //
    @Args('name') name: string,
    @Args('productid') productId: string,
  ) {
    return this.thumnailService.create({ imageurl, name, productId });
  }
}
