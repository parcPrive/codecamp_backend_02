import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Product } from '../products/entities/product.entity';
import { ProductThumnail } from './entities/productThumnail.entity';
import { ThumnailResolver } from './thumnail.resolver';
import { ThumnailService } from './thumnail.service';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Product, //
      ProductThumnail,
    ]),
  ],
  providers: [ThumnailResolver, ThumnailService],
})
export class ThumnailModule {}
