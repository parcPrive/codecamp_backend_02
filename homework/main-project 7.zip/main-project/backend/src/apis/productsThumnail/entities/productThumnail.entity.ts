import { Field, Int, ObjectType } from '@nestjs/graphql';
import { Product } from 'src/apis/products/entities/product.entity';
import {
  Column,
  CreateDateColumn,
  Entity,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity()
@ObjectType()
export class ProductThumnail {
  @PrimaryGeneratedColumn('uuid')
  @Field(() => String)
  id: string;

  @Column()
  @Field(() => String)
  imageurl: string;

  @Column()
  @Field(() => String)
  name: string;

  @Column({ default: 1 })
  @Field(() => Int)
  imagecheck: string;

  @CreateDateColumn()
  @Field(() => Date)
  dateAt: Date;

  @ManyToOne(() => Product)
  @Field(() => Product)
  product: Product;
}
