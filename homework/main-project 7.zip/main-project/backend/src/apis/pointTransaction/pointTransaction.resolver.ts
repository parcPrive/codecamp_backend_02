import { HttpException, UseGuards } from '@nestjs/common';
import { Args, Mutation, Resolver } from '@nestjs/graphql';
import { GqlAuthAccessGuard } from 'src/commons/auth/gql-auth.guard';
import { CurrentUser, ICurrentUser } from 'src/commons/auth/gql-user.param';
import { PointTransaction } from './entities/pointTransaction.entity';
import { PointTransactionService } from './pointTransaction.service';
import { IamportService } from '../iamport/iamport.service';
@Resolver()
export class PointTransactionResolver {
  constructor(
    private readonly pointTransactionService: PointTransactionService, //
    private readonly iamportService: IamportService,
  ) {}

  @UseGuards(GqlAuthAccessGuard)
  @Mutation(() => PointTransaction)
  async createPointTransaction(
    @Args('impUid') impUid: string,
    @Args('amount') amount: number,
    @Args('merchantUid') merchantUid: string,
    @CurrentUser() currentUser: ICurrentUser,
  ) {
    //검증로직들!!!
    // 1. 아임포트에 요청해서 결제 완료 기록이 존재하는 확인한다.
    const token = await this.iamportService.getToken();
    await this.iamportService.checkPaid({ impUid, amount, token });
    // 2. pointTransaction 테이블에는 impUid가 1번만 존재해야 합니다. (중복 결제를 체크)
    await this.pointTransactionService.checkDuplicate({ impUid });
    return this.pointTransactionService.create({
      impUid,
      amount,
      merchantUid,
      currentUser,
    });
  }

  @UseGuards(GqlAuthAccessGuard)
  @Mutation(() => PointTransaction)
  async cancelPointTransaction(
    @Args('importUid') impUid: string,
    @Args('merchantUid') merchantUid: string,
    @CurrentUser() currentUser: ICurrentUser,
  ) {
    //검증로직
    //1. 이미 취소된 건인지 확인
    await this.pointTransactionService.checkAlreadycanceled({ impUid });
    //2. 취소하기에 충분한 내 포인트 잔액이 남아있는지
    await this.pointTransactionService.checkHasCancelablePoint({
      impUid,
      currentUser,
    });
    //3. 실제로 아임포트에 취소 요청하기
    const token = await this.iamportService.getToken();
    const canceledAmount = await this.iamportService.cancel({ impUid, token });
    //4. pointTransaction 테이블에 결제 취소 등록하기
    await this.pointTransactionService.cancel({
      impUid,
      amount: canceledAmount,
      currentUser,
      merchantUid,
    });
    //결제취소하기
  }
}
