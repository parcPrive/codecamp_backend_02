//   export class checkemail{
//   // 1. 가입확인
//    let user = await this.userService.findOne({ email: req.user.email });

//    // 2. 회원가입
//    if (!user) {
//      user = await this.userService.create({
//        email: req.user.email,
//        hashedPassword: req.user.pw,
//        phone: req.user.phone,
//        person: req.user.person,
//        address: req.user.address,
//      });
//    }
//    // 3. 로그인
//    this.authService.setRefreshToken({ user, res });

//    res.redirect(
//      'http://localhost:5500/homework/main-project/fontend/login/index.html',
//    );
// }
