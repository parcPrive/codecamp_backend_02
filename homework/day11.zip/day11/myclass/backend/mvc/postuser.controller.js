import { UserService } from "./controllers/services/user.service";
import axios from 'axios'
export class PostUserController{
 
}