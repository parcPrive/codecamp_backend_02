import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UserService } from '../user/user.service';

@Injectable()
export class AuthService {
  constructor(
    private readonly jwtService: JwtService,
    private readonly userService: UserService,
  ) {}

  setRefreshToken({ user, res }) {
    const refreshToken = this.jwtService.sign(
      { email: user.email, sub: user.id },
      { secret: 'myRefreshKey', expiresIn: '2w' },
    );
    res.setHeader('Set-Cookie', `refreshToken=${refreshToken}; path=/;`);
  }
  getAccessToken({ user }) {
    return this.jwtService.sign(
      { email: user.email, sub: user.id },
      { secret: 'myAccessKey', expiresIn: '24h' },
    );
  }
  async login({ req, res }) {
    // 1. 가입확인
    let user = await this.userService.findOne({ email: req.user.email });
    // 2. 회원가입
    if (!user) {
      user = await this.userService.create({
        email: req.user.email,
        hashedPassword: req.user.pw,
        phone: req.user.phone,
        person: req.user.person,
        address: req.user.address,
      });
    }
    // 3. 로그인
    this.setRefreshToken({ user, res });
    res.redirect('http://localhost:5500/fontend/login/index.html');
  }
}
